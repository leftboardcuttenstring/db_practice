SELECT Nazvanie
FROM Strani
WHERE Nazvanie LIKE '[�-�]%';
