CREATE TABLE Strani (
    Nazvanie VARCHAR(50),
    Stolitsa VARCHAR(50),
    Ploshad INT,
    Naselenie BIGINT,
    Continent VARCHAR(20)
);