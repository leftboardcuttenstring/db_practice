SELECT Nazvanie, Stolitsa, Ploshad, Naselenie, Continent
FROM Strani
WHERE Nazvanie NOT LIKE '[�-�]%' OR Nazvanie LIKE '�%';