SELECT Nazvanie
FROM Strani
WHERE Nazvanie NOT LIKE '�%';
