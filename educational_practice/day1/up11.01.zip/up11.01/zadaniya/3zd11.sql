SELECT Nazvanie
FROM Strani
WHERE Stolitsa IS NOT NULL AND Stolitsa != '';
