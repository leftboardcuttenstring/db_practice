SELECT TOP 5 Nazvanie, Stolitsa
FROM Strani
ORDER BY Ploshad DESC;
