SELECT Nazvanie
FROM Strani
WHERE Nazvanie LIKE '[�-�]%' AND Nazvanie NOT LIKE '�%';
