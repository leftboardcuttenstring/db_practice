create table Akademiki (
	Akademiki_ID int identity(1,1) not null primary key,
	Akademiki_FIO nvarchar(100) not null,
	Akademiki_Data_Rozhdeniya date not null,
	Akademiki_Specializaciya nvarchar(50) not null,
	Akademiki_God_Prisvoeniya_Zvaniya int not null
)